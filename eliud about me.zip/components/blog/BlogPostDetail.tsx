import React from 'react';
import { BlogPostProps } from '../../types';

// Note: In a real implementation, you'd want to use a markdown renderer like react-markdown
// For simplicity, this is a basic version that doesn't actually render markdown

interface BlogPostDetailProps {
  post: BlogPostProps;
  onBack: () => void;
}

export const BlogPostDetail: React.FC<BlogPostDetailProps> = ({ post, onBack }) => {
  // Function to create basic markdown rendering (very simplified)
  const renderContent = (content: string) => {
    // Split content into paragraphs
    const paragraphs = content.split('\n\n');
    
    return paragraphs.map((paragraph, index) => {
      // Handle headings
      if (paragraph.startsWith('# ')) {
        return <h1 key={index} className="text-3xl font-bold mb-6 mt-8">{paragraph.substring(2)}</h1>;
      } else if (paragraph.startsWith('## ')) {
        return <h2 key={index} className="text-2xl font-bold mb-4 mt-8">{paragraph.substring(3)}</h2>;
      } else if (paragraph.startsWith('### ')) {
        return <h3 key={index} className="text-xl font-bold mb-3 mt-6">{paragraph.substring(4)}</h3>;
      }
      // Handle code blocks
      else if (paragraph.startsWith('```')) {
        const codeContent = paragraph.substring(paragraph.indexOf('\n') + 1, paragraph.lastIndexOf('```'));
        return (
          <pre key={index} className="bg-[var(--secondary-bg)] p-4 rounded-lg overflow-x-auto my-6">
            <code>{codeContent}</code>
          </pre>
        );
      }
      // Handle lists (very basic)
      else if (paragraph.includes('- ')) {
        const items = paragraph.split('- ').filter(item => item.trim() !== '');
        return (
          <ul key={index} className="list-disc list-inside my-4 ml-4">
            {items.map((item, i) => (
              <li key={i} className="mb-2">{item.trim()}</li>
            ))}
          </ul>
        );
      }
      // Default paragraph
      else {
        return <p key={index} className="mb-4 leading-relaxed">{paragraph}</p>;
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto bg-[var(--card-bg)] rounded-xl overflow-hidden shadow-lg">
      {/* Back button */}
      <button 
        onClick={onBack}
        className="flex items-center text-[var(--accent-color)] hover:underline ml-6 mt-6"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clipRule="evenodd" />
        </svg>
        Back to Blog
      </button>
      
      {/* Header Image */}
      <div className="relative h-64 sm:h-80 overflow-hidden">
        <img 
          src={post.coverImage} 
          alt={post.title} 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Content */}
      <div className="p-6 sm:p-8">
        {/* Post Metadata */}
        <div className="flex flex-wrap justify-between items-center text-sm text-[var(--secondary-text)] mb-4">
          <div className="flex items-center mb-2 sm:mb-0">
            {post.authorImage ? (
              <img 
                src={post.authorImage} 
                alt={post.author} 
                className="w-10 h-10 rounded-full mr-3"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[var(--accent-color)] mr-3 flex items-center justify-center text-white font-bold">
                {post.author.charAt(0)}
              </div>
            )}
            <div>
              <div className="font-medium text-[var(--primary-text)]">{post.author}</div>
              <div className="text-xs">{post.date} · {post.readTime}</div>
            </div>
          </div>
          
          <div className="px-3 py-1 bg-[var(--accent-gradient)] text-black rounded-full text-xs font-medium">
            {post.category}
          </div>
        </div>
        
        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-extrabold mb-6 text-[var(--primary-text)]">
          {post.title}
        </h1>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-8">
          {post.tags.map((tag, index) => (
            <span 
              key={index} 
              className="bg-[var(--secondary-bg)] text-[var(--accent-color)] px-3 py-1 rounded-full text-xs"
            >
              #{tag}
            </span>
          ))}
        </div>
        
        {/* Article Content */}
        <article className="prose prose-lg max-w-none text-[var(--primary-text)]">
          {renderContent(post.content)}
        </article>
        
        {/* Share and Actions */}
        <div className="mt-12 pt-6 border-t border-[var(--card-border)] flex flex-wrap justify-between items-center">
          <div className="text-sm text-[var(--secondary-text)]">
            Thanks for reading!
          </div>
          
          <div className="flex space-x-4">
            <button className="text-[var(--secondary-text)] hover:text-[var(--primary-text)] transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </button>
            <button className="text-[var(--secondary-text)] hover:text-[var(--primary-text)] transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}; 