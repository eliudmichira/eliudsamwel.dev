import React, { useState, useEffect } from 'react';
import { BlogCard } from './BlogCard';
import { BlogPostDetail } from './BlogPostDetail';
import { BlogPostProps } from '../../types';
import { blogPosts } from '../../data/blogData';

export const BlogPage: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPostProps | null>(null);
  const [posts, setPosts] = useState<BlogPostProps[]>(blogPosts);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  // Extract unique categories from blog posts
  const categories = ['all', ...Array.from(new Set(blogPosts.map(post => post.category)))];
  
  // Filter posts based on category and search term
  useEffect(() => {
    const filtered = blogPosts.filter((post) => {
      const categoryMatch = activeCategory === 'all' || post.category === activeCategory;
      const searchMatch = !searchTerm || 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      return categoryMatch && searchMatch;
    });
    
    setPosts(filtered);
  }, [activeCategory, searchTerm]);
  
  // Handle post selection
  const handleSelectPost = (post: BlogPostProps) => {
    setSelectedPost(post);
    window.scrollTo(0, 0);
  };
  
  // Handle back to blog list
  const handleBackToBlog = () => {
    setSelectedPost(null);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold mb-4 sm:text-5xl">
          My <span className="bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-600 bg-clip-text text-transparent">Blog</span>
        </h1>
        <p className="text-[var(--secondary-text)] max-w-2xl mx-auto text-lg">
          Thoughts, tutorials, and insights about web development, blockchain, and more
        </p>
      </div>
      
      {/* Show blog list or post detail */}
      {selectedPost ? (
        <BlogPostDetail post={selectedPost} onBack={handleBackToBlog} />
      ) : (
        <>
          {/* Filters and Search */}
          <div className="mb-12">
            {/* Search input */}
            <div className="max-w-md mx-auto mb-8">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search articles..."
                  className="w-full p-3 pl-10 rounded-lg bg-[var(--card-bg)] border border-[var(--card-border)] text-[var(--primary-text)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)]"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--secondary-text)]">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                {searchTerm && (
                  <button 
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--secondary-text)] hover:text-[var(--primary-text)]"
                    onClick={() => setSearchTerm('')}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>
            </div>
            
            {/* Category filters */}
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300
                    ${activeCategory === category ? 
                      'bg-[var(--accent-gradient)] text-black' : 
                      'bg-[var(--secondary-bg)] text-[var(--secondary-text)] hover:text-[var(--primary-text)]'
                    }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category === 'all' ? 'All Categories' : category}
                </button>
              ))}
            </div>
          </div>
          
          {/* Blog Posts Grid */}
          {posts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {posts.map((post) => (
                <BlogCard
                  key={post.id}
                  post={post}
                  onClick={() => handleSelectPost(post)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-[var(--secondary-text)] text-xl mb-4">No articles found</div>
              <button
                onClick={() => {
                  setActiveCategory('all');
                  setSearchTerm('');
                }}
                className="px-5 py-2 rounded-lg bg-[var(--accent-gradient)] text-black font-medium"
              >
                Reset Filters
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}; 