import React from 'react';
import { BlogPostProps } from '../../types';

interface BlogCardProps {
  post: BlogPostProps;
  onClick: () => void;
}

export const BlogCard: React.FC<BlogCardProps> = ({ post, onClick }) => {
  return (
    <div 
      className="blog-card bg-[var(--card-bg)] rounded-lg overflow-hidden shadow-md border border-[var(--card-border)] hover:shadow-xl transition-all duration-300 cursor-pointer hover:-translate-y-2 animate-fade-in"
      onClick={onClick}
    >
      <div className="relative overflow-hidden h-48">
        <img 
          src={post.coverImage} 
          alt={post.title} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute top-0 right-0 bg-[var(--accent-gradient)] text-black px-3 py-1 m-3 rounded text-xs font-medium">
          {post.category}
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2 text-[var(--primary-text)] line-clamp-2">
          {post.title}
        </h3>
        
        <p className="text-[var(--secondary-text)] mb-4 text-sm line-clamp-3">
          {post.excerpt}
        </p>
        
        <div className="flex justify-between items-center text-xs text-[var(--secondary-text)]">
          <div className="flex items-center">
            {post.authorImage ? (
              <img 
                src={post.authorImage} 
                alt={post.author} 
                className="w-6 h-6 rounded-full mr-2"
              />
            ) : (
              <div className="w-6 h-6 rounded-full bg-[var(--accent-color)] mr-2 flex items-center justify-center text-white">
                {post.author.charAt(0)}
              </div>
            )}
            <span>{post.author}</span>
          </div>
          
          <div className="flex items-center">
            <span className="mr-3">{post.date}</span>
            <span>{post.readTime}</span>
          </div>
        </div>
        
        <div className="mt-4 flex flex-wrap gap-2">
          {post.tags.slice(0, 3).map((tag, index) => (
            <span 
              key={index} 
              className="bg-[var(--secondary-bg)] text-[var(--accent-color)] px-2 py-1 rounded text-xs"
              onClick={(e) => e.stopPropagation()}
            >
              #{tag}
            </span>
          ))}
          {post.tags.length > 3 && (
            <span className="text-[var(--secondary-text)] text-xs">
              +{post.tags.length - 3} more
            </span>
          )}
        </div>
        
      </div>
    </div>
  );
}; 