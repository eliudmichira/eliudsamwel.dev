
import React, { useState } from 'react';

interface FABProps {
  onNavigate: (pageId: string) => void;
}

interface FABMenuItem {
  id: string;
  label: string;
  pageId: string; // For App.tsx navigation state
  icon: JSX.Element;
  actionType: 'navigate' | 'function';
  actionValue?: string; // pageId for navigate, or function name
}

const PlusIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
  </svg>
);
const XIcon = () => (
 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);


export const FloatingActionButton: React.FC<FABProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems: FABMenuItem[] = [
    { id: 'fab-about', label: 'About', pageId: 'About', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>, actionType: 'navigate' },
    { id: 'fab-resume', label: 'Resume', pageId: 'Resume', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>, actionType: 'navigate' },
    { id: 'fab-projects', label: 'Projects', pageId: 'Projects', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>, actionType: 'navigate' },
  ];

  const handleFabClick = () => setIsOpen(!isOpen);
  const handleItemClick = (item: FABMenuItem) => {
    if (item.actionType === 'navigate') {
      onNavigate(item.pageId);
    }
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-6 left-6 sm:bottom-8 sm:left-8 z-[999]">
      <div 
        className={`floating-menu absolute bottom-[calc(100%_+_10px)] left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-3 transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${isOpen ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible translate-y-4'}`}
      >
        {menuItems.map((item) => (
          <button
            key={item.id}
            title={item.label}
            onClick={() => handleItemClick(item)}
            className="w-12 h-12 sm:w-14 sm:h-14 bg-[var(--card-bg)] rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] border-2 border-[var(--accent-color)] text-[var(--accent-color)] hover:bg-[var(--accent-gradient)] hover:text-black hover:border-transparent hover:scale-110 shadow-lg"
            aria-label={item.label}
          >
            {item.icon}
          </button>
        ))}
      </div>
      <button
        id="floating-action-button"
        onClick={handleFabClick}
        className="w-14 h-14 sm:w-16 sm:h-16 bg-[var(--accent-gradient)] rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-xl hover:scale-110 hover:shadow-2xl text-black"
        aria-expanded={isOpen}
        aria-label={isOpen ? "Close quick actions menu" : "Open quick actions menu"}
      >
        {isOpen ? <XIcon/> : <PlusIcon/>}
      </button>
    </div>
  );
};
