import React from 'react';
import profileImage from '../profile.jpg'; // Import the local profile image

interface PageHeaderSectionProps {
  onNavigate: (pageId: string) => void;
}

export const PageHeaderSection: React.FC<PageHeaderSectionProps> = ({ onNavigate }) => {
  // Using the imported image instead of Unsplash placeholder
  const profileImageUrl = profileImage;

  return (
    <section id="home-hero" className="relative min-h-[calc(100vh-120px)] sm:min-h-[calc(100vh-160px)] flex items-center justify-center text-center sm:text-left -mt-10 sm:-mt-16 pt-16 pb-8"> {/* Adjust mt to pull up if header is tall */}
      <div className="container mx-auto px-4 sm:px-6 py-12 sm:py-24 relative z-10"> {/* content-wrapper */}
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-3/5 lg:w-1/2 mb-12 md:mb-0 md:pr-8 lg:pr-12">
            <h3 className="text-lg font-medium text-[var(--accent-color-amber)] mb-2 fade-in-up">Hi, I'm</h3>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-5 sm:mb-6 fade-in-up delay-100">
              Eliud Michira <span className="gradient-text">Samwel</span>
            </h1>
            <h2 className="text-2xl sm:text-3xl font-semibold mb-6 text-[var(--secondary-text)] fade-in-up delay-200">
              Software Developer & Tech Innovator
            </h2>
            <p className="text-base sm:text-lg mb-8 max-w-lg text-[var(--secondary-text)] leading-relaxed fade-in-up delay-300">
              Building impactful digital solutions at the intersection of web, mobile, and blockchain technology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 fade-in-up delay-400 justify-center sm:justify-start">
              <button
                onClick={() => onNavigate('Projects')}
                className="accent-button px-8 py-3.5 rounded-xl text-center font-semibold text-sm sm:text-base
                           bg-[var(--accent-gradient)] text-black
                           hover:shadow-lg hover:brightness-110 transition-all duration-300 ease-in-out transform hover:scale-105"
              >
                View My Work
              </button>
              <button
                onClick={() => onNavigate('Contact')}
                className="px-8 py-3.5 rounded-xl text-center font-semibold text-sm sm:text-base
                           border-2 border-[var(--accent-color)] text-[var(--accent-color)]
                           hover:bg-[var(--accent-color)] hover:text-black transition-all duration-300 ease-in-out transform hover:scale-105"
              >
                Get In Touch
              </button>
            </div>
          </div>
          <div className="md:w-2/5 lg:w-1/2 flex justify-center items-center fade-in-up delay-500">
            <div className="relative w-56 h-56 sm:w-64 sm:h-64 md:w-72 md:h-72 lg:w-80 lg:h-80 animate-float">
              <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-color)] to-[var(--accent-color-red)] rounded-full opacity-20 blur-2xl"></div>
              <img 
                src={profileImageUrl} 
                alt="Eliud Samwel" 
                className="w-full h-full object-cover rounded-full border-4 border-[var(--accent-color)]/50 relative z-10 shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
