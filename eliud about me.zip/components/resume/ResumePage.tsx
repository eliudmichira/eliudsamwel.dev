import React, { useState } from 'react';
import { resumeData } from '../../data/resumeContent';
import { ResumeSection } from './ResumeSection';
import { ResumeSkillBadge } from './ResumeSkillBadge';
import { ResumeContactLink } from './ResumeContactLink';
import { ResumeExperienceItem } from './ResumeExperienceItem';
import { ResumeEducationItem } from './ResumeEducationItem';
import { ResumeReferenceItem } from './ResumeReferenceItem';
import { ResumeSkillBar } from './ResumeSkillBar';
import { SkillsRadarChart } from './SkillsRadarChart';
import { DownloadResumeButton } from './DownloadResumeButton';

interface ResumeTabProps {
  activeTab: string;
  setActiveTab: React.Dispatch<React.SetStateAction<string>>;
}

const ResumeTabs: React.FC<ResumeTabProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'skills', label: 'Skills' },
    { id: 'experience', label: 'Experience' },
    { id: 'education', label: 'Education' }
  ];
  
  return (
    <div className="flex flex-wrap justify-center gap-2 mb-8 border-b border-[var(--card-border)] pb-2">
      {tabs.map(tab => (
        <button
          key={tab.id}
          className={`px-5 py-2 rounded-t-lg font-medium transition-all duration-300 ${
            activeTab === tab.id 
              ? 'bg-[var(--accent-gradient)] text-black' 
              : 'bg-[var(--secondary-bg)] text-[var(--secondary-text)] hover:bg-opacity-70'
          }`}
          onClick={() => setActiveTab(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};

export const ResumePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  
  const { 
    fullName, accentName, jobTitle, location, contactInfo,
    professionalSummary, coreCompetencies, experience,
    education, professionalDevelopment, references 
  } = resumeData;
  
  // Create a dataset for the radar chart
  const radarChartSkills = coreCompetencies.skills
    .filter(skill => skill.level)
    .slice(0, 8); // Limit to 8 skills for the chart

  return (
    <div className="max-w-4xl mx-auto">
      {/* Resume Header Section */}
      <div className="text-center mb-8 sm:mb-12">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mb-2">
          {fullName}{' '}
          <span className="bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-600 bg-clip-text text-transparent">
            {accentName}
          </span>
        </h1>
        <p className="text-base sm:text-lg text-[var(--secondary-text)] mb-4">{jobTitle}</p>
        
        <div className="flex items-center justify-center gap-2 text-[var(--secondary-text)] mb-6">
          <location.icon className="w-5 h-5 fill-current text-yellow-500" />
          <span>{location.text}</span>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center items-center gap-x-6 gap-y-3 flex-wrap mb-8">
          {contactInfo.map((item, index) => (
            <ResumeContactLink key={index} {...item} />
          ))}
        </div>
        
        <div className="flex justify-center">
          <DownloadResumeButton />
        </div>
      </div>
      
      {/* Tabs Navigation */}
      <ResumeTabs activeTab={activeTab} setActiveTab={setActiveTab} />
      
      {/* Tab Content */}
      <div className="transition-all duration-500 ease-in-out">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            <ResumeSection title="Professional Summary">
              <p className="text-[var(--primary-text)] leading-relaxed">{professionalSummary}</p>
            </ResumeSection>

            <ResumeSection title="Core Competencies">
              <div className="flex flex-wrap gap-2 mb-6">
                {coreCompetencies.skills.map((skill, index) => (
                  <ResumeSkillBadge key={index} name={skill.name} level={skill.level} />
                ))}
              </div>
              <ul className="list-disc list-inside space-y-2 text-[var(--primary-text)]">
                {coreCompetencies.detailed.map((competency, index) => (
                  <li key={index}>
                    <strong className="font-semibold text-[var(--primary-text)]">{competency.category}:</strong> {competency.items}
                  </li>
                ))}
              </ul>
            </ResumeSection>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ResumeSection title="Experience" defaultExpanded={false}>
                <div className="space-y-6">
                  {experience.slice(0, 2).map((item, index) => (
                    <ResumeExperienceItem key={index} {...item} />
                  ))}
                  {experience.length > 2 && (
                    <div className="text-center pt-2">
                      <button 
                        onClick={() => setActiveTab('experience')} 
                        className="text-[var(--accent-color)] hover:underline"
                      >
                        View all experience →
                      </button>
                    </div>
                  )}
                </div>
              </ResumeSection>

              <ResumeSection title="Education" defaultExpanded={false}>
                <div className="space-y-4">
                  {education.map((item, index) => (
                    <ResumeEducationItem key={index} {...item} />
                  ))}
                </div>
              </ResumeSection>
            </div>
          </>
        )}
        
        {/* Skills Tab */}
        {activeTab === 'skills' && (
          <>
            <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--card-border)] p-6 mb-8">
              <h2 className="text-xl font-bold mb-6 text-center text-[var(--primary-text)]">Skills Visualization</h2>
              <SkillsRadarChart skills={radarChartSkills} />
            </div>
            
            <ResumeSection title="Technical Skills">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                {coreCompetencies.skills.map((skill, index) => (
                  <ResumeSkillBar 
                    key={index} 
                    name={skill.name} 
                    level={skill.level || 50} 
                  />
                ))}
              </div>
            </ResumeSection>
            
            <ResumeSection title="Skill Categories">
              <ul className="list-disc list-inside space-y-2 text-[var(--primary-text)]">
                {coreCompetencies.detailed.map((competency, index) => (
                  <li key={index} className="animate-fade-in" style={{animationDelay: `${index * 100}ms`}}>
                    <strong className="font-semibold text-[var(--primary-text)]">{competency.category}:</strong> {competency.items}
                  </li>
                ))}
              </ul>
            </ResumeSection>
            
            <ResumeSection title="Professional Development">
              <ul className="list-disc list-inside space-y-2 text-[var(--primary-text)]">
                {professionalDevelopment.map((item, index) => (
                  <li key={index}>
                    <span className="font-semibold text-[var(--primary-text)]">{item.item}</span>
                    {item.source && <span className="text-[var(--secondary-text)]"> – {item.source}</span>}
                    {item.date && <span className="text-[var(--secondary-text)] text-sm"> ({item.date})</span>}
                  </li>
                ))}
              </ul>
            </ResumeSection>
          </>
        )}
        
        {/* Experience Tab */}
        {activeTab === 'experience' && (
          <ResumeSection title="Professional Experience">
            <div className="space-y-8">
              {experience.map((item, index) => (
                <ResumeExperienceItem key={index} {...item} />
              ))}
            </div>
          </ResumeSection>
        )}
        
        {/* Education Tab */}
        {activeTab === 'education' && (
          <>
            <ResumeSection title="Education">
              <div className="space-y-6">
                {education.map((item, index) => (
                  <ResumeEducationItem key={index} {...item} />
                ))}
              </div>
            </ResumeSection>
            
            <ResumeSection title="References">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                {references.map((item, index) => (
                  <ResumeReferenceItem key={index} {...item} />
                ))}
              </div>
            </ResumeSection>
          </>
        )}
      </div>
      
      {/* Footer with download button */}
      <div className="mt-12 text-center">
        <DownloadResumeButton />
        <p className="mt-4 text-sm text-[var(--secondary-text)]">
          Last updated: May 2024
        </p>
      </div>
    </div>
  );
};
