import React, { useState } from 'react';

interface ResumeSkillBadgeProps {
  name: string;
  level?: number;
}

export const ResumeSkillBadge: React.FC<ResumeSkillBadgeProps> = ({ name, level }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  // Determine skill level label if provided
  const getSkillLevelLabel = (level?: number) => {
    if (!level) return null;
    
    if (level >= 90) return 'Expert';
    if (level >= 75) return 'Advanced';
    if (level >= 50) return 'Intermediate';
    if (level >= 25) return 'Familiar';
    return 'Beginner';
  };
  
  return (
    <div 
      className="relative group cursor-pointer transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div 
        className={`inline-block px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-300 border 
          ${isHovered ? 
            'bg-[var(--accent-gradient)] border-transparent text-black shadow-md transform -translate-y-1' : 
            'bg-[var(--secondary-bg)] border-[var(--card-border)] text-[var(--primary-text)]'}`
        }
      >
        {name}
      </div>
      
      {level && isHovered && (
        <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-[var(--card-bg)] text-[var(--primary-text)] text-xs font-medium px-2.5 py-1 rounded shadow-lg border border-[var(--card-border)] whitespace-nowrap z-10 animate-fade-in">
          <div className="flex items-center gap-2">
            <div className="w-16 h-1.5 bg-[var(--secondary-bg)] rounded-full overflow-hidden">
              <div 
                className="h-full rounded-full bg-[var(--accent-gradient)]" 
                style={{width: `${level}%`}}
              ></div>
            </div>
            <span>{getSkillLevelLabel(level)}</span>
          </div>
        </div>
      )}
    </div>
  );
};
