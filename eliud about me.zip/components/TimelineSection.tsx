import React, { useRef, useState, useEffect } from 'react';
import { TimelineItemCard } from './TimelineItemCard';
import { TimelineEvent } from '../types';
import { ProgressBar }  from './ProgressBar';

interface TimelineSectionProps {
  timelineEvents: TimelineEvent[];
}

export const TimelineSection: React.FC<TimelineSectionProps> = ({ timelineEvents }) => {
  const timelineContainerRef = useRef<HTMLDivElement>(null);
  const timelineDotRef = useRef<HTMLDivElement>(null);
  const [dotVisible, setDotVisible] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeSectionIndex, setActiveSectionIndex] = useState(-1); // Track active section

  // Create CSS styles directly in the component
  useEffect(() => {
    // Create a style element
    const styleEl = document.createElement('style');
    styleEl.textContent = `
      .timeline-item.active .role-icon {
        transform: scale(1.1) !important;
        box-shadow: 0 0 20px rgba(255, 202, 40, 0.4) !important;
      }
      
      .timeline-item.active h3 {
        color: var(--accent-color) !important;
      }
      
      .timeline-item.active .group {
        border-color: var(--accent-color) !important;
        box-shadow: var(--card-glow) !important;
      }
      
      @media (min-width: 768px) {
        .timeline-item:nth-child(odd) .group {
          transform: translateX(-8px) !important;
        }
        
        .timeline-item:nth-child(even) .group {
          transform: translateX(8px) !important;
        }
        
        .timeline-item.active:nth-child(odd) .group {
          transform: translateX(-12px) translateY(-4px) !important;
        }
        
        .timeline-item.active:nth-child(even) .group {
          transform: translateX(12px) translateY(-4px) !important;
        }
      }
    `;
    
    // Append to head
    document.head.appendChild(styleEl);
    
    // Cleanup on unmount
    return () => {
      document.head.removeChild(styleEl);
    };
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (!timelineContainerRef.current) return;

      const container = timelineContainerRef.current;
      const scrollY = window.scrollY || window.pageYOffset;
      const windowHeight = window.innerHeight;
      const viewportCenter = scrollY + windowHeight / 2;

      // For Moving Dot with enhanced animation
      const dot = timelineDotRef.current;
      if(dot) {
        const triggerPointDot = scrollY + windowHeight * 0.66;
        const timelineStartDot = container.offsetTop;
        const timelineHeightDot = container.offsetHeight;
        const timelineEndDot = timelineStartDot + timelineHeightDot - dot.offsetHeight - 100;

        let progressDot = 0;
        if (triggerPointDot > timelineStartDot && scrollY < (timelineStartDot + timelineHeightDot - windowHeight * 0.1) ) {
           progressDot = (triggerPointDot - timelineStartDot) / (timelineEndDot - timelineStartDot);
        } else if (scrollY >= (timelineStartDot + timelineHeightDot - windowHeight * 0.1)) {
          progressDot = 1;
        } else if (triggerPointDot <= timelineStartDot) {
          progressDot = 0;
        }
        progressDot = Math.max(0, Math.min(1, progressDot));
        const dotMaxY = timelineHeightDot - dot.offsetHeight - 80;
        const dotPositionY = dotMaxY * progressDot;
        dot.style.top = `${Math.min(dotMaxY, Math.max(0, dotPositionY))}px`;
        
        // Enhanced dot visibility transition
        setDotVisible(progressDot > 0.01 && progressDot < 0.99);
        
        // Calculate which timeline section is active based on dot position
        const dotCurrentY = dotPositionY + timelineStartDot;
        const sectionElements = container.querySelectorAll('.timeline-item');
        let activeIndex = -1;
        
        sectionElements.forEach((section, index) => {
          const rect = (section as HTMLElement).getBoundingClientRect();
          const sectionTop = rect.top + scrollY;
          const sectionBottom = sectionTop + rect.height;
          
          if (dotCurrentY >= sectionTop - 100 && dotCurrentY <= sectionBottom + 100) {
            activeIndex = index;
          }
        });
        
        setActiveSectionIndex(activeIndex);
      }

      // Enhanced Progress Bar calculation
      const triggerPointProgress = scrollY + windowHeight * (2/3);
      const timelineStartProgress = container.offsetTop;
      const timelineHeightProgress = container.offsetHeight;
      
      let progressVal = 0;
      if (triggerPointProgress > timelineStartProgress && scrollY < (timelineStartProgress + timelineHeightProgress)) {
         progressVal = (triggerPointProgress - timelineStartProgress) / (timelineHeightProgress);
      } else if (scrollY >= (timelineStartProgress + timelineHeightProgress)) {
        progressVal = 1;
      }
      progressVal = Math.max(0, Math.min(1, progressVal * 1.05)); // Slightly overshooting for better UX
      setScrollProgress(progressVal * 100);
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleScroll);
    handleScroll(); 

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, []);

  return (
    <section className="my-16 sm:my-24 py-12 sm:py-16 relative">
      <div className="text-center mb-12 sm:mb-16 fade-in-up">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-extrabold mb-3 sm:mb-4">
          My <span className="gradient-text">Journey</span>
        </h2>
        <p className="text-lg text-[var(--secondary-text)] max-w-xl mx-auto">
          Follow my professional path and milestones.
        </p>
      </div>
      
      {/* Enhanced progress bar with smoother animation */}
      <ProgressBar progress={scrollProgress} />

      <div ref={timelineContainerRef} className="relative mt-12 sm:mt-16 max-w-6xl mx-auto px-4 sm:px-6 min-h-[1000px]" id="timeline-section-container">
        {/* Enhanced Timeline Line with gradient and glow effects */}
        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-1 md:w-1.5 bg-gradient-to-b from-[var(--accent-color)] via-[var(--accent-color-amber)] to-[var(--accent-color-red)] opacity-60 transform md:-translate-x-1/2 z-[1] rounded-full shadow-lg">
          {/* Top dot with enhanced pulse animation */}
          <div className="absolute top-[-8px] left-1/2 transform -translate-x-1/2 w-4 h-4 bg-[var(--accent-gradient)] rounded-full shadow-[var(--dot-glow)] animate-pulse"></div>
          
          {/* Bottom dot with enhanced glow */}
          <div className="absolute bottom-[-8px] left-1/2 transform -translate-x-1/2 w-4 h-4 bg-[var(--accent-gradient)] rounded-full shadow-[var(--dot-glow)]"></div>
        </div>

        {/* Enhanced Timeline Moving Dot with better animation and glow effects */}
        <div 
          ref={timelineDotRef}
          className={`absolute left-4 md:left-1/2 w-8 h-8 sm:w-9 sm:h-9 bg-[var(--accent-gradient)] rounded-full 
                     transform md:-translate-x-1/2 z-[15] 
                     shadow-[0_0_15px_rgba(255,202,40,0.7)]
                     border-4 border-[var(--primary-bg)]
                     transition-all duration-500 ease-out
                     ${dotVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}
          style={{ top: '0px' }} 
        >
          {/* Inner pulse animation */}
          <div className="absolute inset-[-8px] sm:inset-[-10px] rounded-full bg-[var(--accent-gradient)] opacity-25 animate-customPulse" style={{animationDuration: '3s'}}></div>
          
          {/* Outer glow effect */}
          <div className="absolute inset-[-4px] sm:inset-[-5px] rounded-full bg-[var(--accent-color)] opacity-20 blur-[8px]"></div>
        </div>
        
        {/* Timeline items container */}
        <div className="relative">
          {timelineEvents.map((event, index) => (
            <div 
              key={event.id} 
              className={`timeline-item ${activeSectionIndex === index ? 'active' : ''}`}
              data-index={index}
            >
              <TimelineItemCard event={event} isOdd={index % 2 === 0} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
