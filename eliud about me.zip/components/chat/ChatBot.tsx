import React, { useState, useRef, useEffect } from 'react';
import { GEMINI_API_KEY, chatConfig } from '../../config/chatConfig';
import { getFormattedContext } from '../../config/customContext';
import '../../styles/chatbot.css';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  isRead?: boolean;
  reaction?: 'like' | 'dislike' | null;
}

export const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'online' | 'offline'>('online');
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Add initial welcome message
  useEffect(() => {
    setMessages([
      {
        id: 'welcome',
        text: chatConfig.initialMessage,
        sender: 'bot',
        timestamp: new Date(),
        isRead: true
      },
    ]);
  }, []);

  // Auto-scroll to bottom of chat on new messages
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Simulate network connectivity check
  useEffect(() => {
    const checkNetworkStatus = () => {
      setConnectionStatus(navigator.onLine ? 'online' : 'offline');
    };

    window.addEventListener('online', checkNetworkStatus);
    window.addEventListener('offline', checkNetworkStatus);

    return () => {
      window.removeEventListener('online', checkNetworkStatus);
      window.removeEventListener('offline', checkNetworkStatus);
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    // Auto resize textarea
    const target = e.target;
    target.style.height = 'auto';
    target.style.height = `${Math.min(target.scrollHeight, 150)}px`;
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    // Add user message to chat
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input.trim(),
      sender: 'user',
      timestamp: new Date(),
      isRead: false
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setApiError(null);

    // Reset textarea height
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }

    try {
      if (!GEMINI_API_KEY || GEMINI_API_KEY.length < 20) {
        throw new Error('API_KEY_MISSING');
      }
      
      // Call Gemini API
      const response = await fetchGeminiResponse(userMessage.text);
      
      // Add bot response to chat
      const botMessage: Message = {
        id: `response-${Date.now()}`,
        text: response,
        sender: 'bot',
        timestamp: new Date(),
        isRead: false
      };

      setMessages((prev) => [...prev, botMessage]);
      
      // Simulate message being read after a delay
      setTimeout(() => {
        setMessages(prev => 
          prev.map(msg => msg.id === botMessage.id ? {...msg, isRead: true} : msg)
        );
      }, 2000);
      
    } catch (error: any) {
      console.error('Error calling Gemini API:', error);
      
      let errorMessage = "I'm sorry, I couldn't process your request. Please try again later.";
      
      // Handle specific error cases
      if (error.message === 'API_KEY_MISSING') {
        errorMessage = "The Gemini API key is not configured. Please add a valid API key in config/chatConfig.ts.";
        setApiError('API_KEY_MISSING');
      } else if (error.message.includes('403')) {
        errorMessage = "API access denied. Please check if your Gemini API key is valid and has the necessary permissions.";
        setApiError('API_KEY_INVALID');
      } else if (error.message.includes('429')) {
        errorMessage = "You've reached the API rate limit. Please try again later.";
        setApiError('RATE_LIMIT');
      } else if (error.message.includes('400')) {
        errorMessage = "There was an issue with the request format. The API couldn't process this type of request.";
        setApiError('BAD_REQUEST');
      } else if (error.message.includes('fetch')) {
        errorMessage = "Network error. Please check your internet connection and try again.";
        setApiError('NETWORK_ERROR');
      }
      
      // Add error message to chat
      const errorMessageObj: Message = {
        id: `error-${Date.now()}`,
        text: errorMessage,
        sender: 'bot',
        timestamp: new Date(),
        isRead: true
      };
      
      setMessages((prev) => [...prev, errorMessageObj]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchGeminiResponse = async (userInput: string): Promise<string> => {
    const apiUrl = `https://generativelanguage.googleapis.com/${chatConfig.apiVersion}/models/${chatConfig.modelName}:generateContent`;
    
    // Get custom context for the website and owner
    const customContext = getFormattedContext();
    
    // Create a prompt that includes the custom context
    const enhancedPrompt = `${customContext}
    
USER QUERY: ${userInput}

Please respond to the user query based on the context provided above.`;
    
    const payload = {
      contents: [
        {
          parts: [
            {
              text: enhancedPrompt,
            },
          ],
        },
      ],
      generationConfig: {
        maxOutputTokens: chatConfig.maxTokens,
      }
    };

    const response = await fetch(`${apiUrl}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API request failed with status ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    
    // Check if the response has the expected structure
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
      throw new Error(`Unexpected API response format: ${JSON.stringify(data)}`);
    }
    
    // Extract the response text from the Gemini API response
    const responseText = data.candidates[0].content.parts[0].text;
    return responseText;
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  // Format timestamp
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString(undefined, {
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  // Handle message reactions
  const handleReaction = (messageId: string, reaction: 'like' | 'dislike') => {
    setMessages(messages.map(msg => {
      if (msg.id === messageId) {
        // Toggle reaction if same button is clicked
        const newReaction = msg.reaction === reaction ? null : reaction;
        return { ...msg, reaction: newReaction };
      }
      return msg;
    }));
  };

  return (
    <div className="chatbot-container">
      {/* Chat Button */}
      <button
        className={`chatbot-toggle ${isOpen ? 'open' : ''}`}
        onClick={toggleChat}
        aria-label="Toggle chat"
      >
        <div className="chatbot-toggle-icon">
          {isOpen ? (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="currentColor" />
            </svg>
          ) : (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H5.17L4.58 16.59L4 17.17V4H20V16Z" fill="currentColor" />
              <path d="M7 9H17V11H7V9ZM7 6H17V8H7V6ZM7 12H13V14H7V12Z" fill="currentColor" />
            </svg>
          )}
        </div>
      </button>

      {/* Chat Window */}
      <div className={`chatbot-window ${isOpen ? 'open' : ''}`}>
        <div className="chatbot-header">
          <div className="chatbot-header-title">
            <div className="chatbot-avatar">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor" />
              </svg>
            </div>
            <h3>Gemini AI Assistant</h3>
          </div>
          <button 
            className="chatbot-close"
            onClick={toggleChat}
            aria-label="Close chat"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="currentColor" />
            </svg>
          </button>
        </div>

        {/* Connection status indicator */}
        {connectionStatus === 'offline' && (
          <div className="chatbot-status">
            You're offline • Messages will be sent when you reconnect
          </div>
        )}

        <div className="chatbot-messages" ref={chatContainerRef}>
          {messages.map((message) => (
            <div
              key={message.id}
              className={`chatbot-message ${message.sender === 'bot' ? 'bot' : 'user'}`}
            >
              {message.sender === 'bot' && (
                <div className="chatbot-message-avatar">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor" />
                  </svg>
                </div>
              )}
              <div className="chatbot-message-content">
                <div className="chatbot-message-text">{message.text}</div>
                
                {/* Message metadata and reactions */}
                <div className="message-metadata">
                  <div className="chatbot-message-time">
                    {formatTime(message.timestamp)}
                    {message.sender === 'user' && (
                      <span className="message-status">
                        {message.isRead ? (
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18 7L9.5 15.5L6 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        ) : (
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                          </svg>
                        )}
                      </span>
                    )}
                  </div>
                </div>
                
                {/* Reaction buttons for bot messages only */}
                {message.sender === 'bot' && (
                  <div className="chatbot-message-reactions">
                    <button 
                      className={`reaction-button ${message.reaction === 'like' ? 'active' : ''}`}
                      onClick={() => handleReaction(message.id, 'like')}
                      aria-label="Like message"
                    >
                      👍 Helpful
                    </button>
                    <button 
                      className={`reaction-button ${message.reaction === 'dislike' ? 'active' : ''}`}
                      onClick={() => handleReaction(message.id, 'dislike')}
                      aria-label="Dislike message"
                    >
                      👎 Not helpful
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="chatbot-message bot">
              <div className="chatbot-message-avatar">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 5C13.66 5 15 6.34 15 8C15 9.66 13.66 11 12 11C10.34 11 9 9.66 9 8C9 6.34 10.34 5 12 5ZM12 19.2C9.5 19.2 7.29 17.92 6 15.98C6.03 13.99 10 12.9 12 12.9C13.99 12.9 17.97 13.99 18 15.98C16.71 17.92 14.5 19.2 12 19.2Z" fill="currentColor" />
                </svg>
              </div>
              <div className="chatbot-message-content">
                <div className="chatbot-message-text">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="chatbot-input-area">
          <textarea
            ref={inputRef}
            className="chatbot-input"
            placeholder="Type your message..."
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            rows={1}
            disabled={connectionStatus === 'offline'}
          />
          <button
            className="chatbot-send"
            onClick={handleSendMessage}
            disabled={!input.trim() || isLoading || connectionStatus === 'offline'}
            aria-label="Send message"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.01 21L23 12L2.01 3L2 10L17 12L2 14L2.01 21Z" fill="currentColor" />
            </svg>
          </button>
        </div>

        {apiError && (
          <div className="chatbot-error-hint">
            {apiError === 'API_KEY_MISSING' && (
              <div>
                <p><strong>Missing API Key</strong></p>
                <p>Add your API key in config/chatConfig.ts</p>
              </div>
            )}
            {apiError === 'API_KEY_INVALID' && (
              <div>
                <p><strong>Invalid API Key</strong></p>
                <p>Check if your key is valid and enabled for Gemini API</p>
              </div>
            )}
            {apiError === 'RATE_LIMIT' && (
              <div>
                <p><strong>Rate Limit Exceeded</strong></p>
                <p>Wait a few minutes and try again</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatBot; 