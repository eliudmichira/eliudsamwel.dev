import React, { useEffect, useRef } from 'react';
import { ProjectCardProps } from '../../types';

interface ProjectDetailModalProps {
  project: ProjectCardProps;
  onClose: () => void;
  isOpen: boolean;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({ 
  project, 
  onClose, 
  isOpen 
}) => {
  const modalRef = useRef<HTMLDivElement>(null);
  
  // Handle clicking outside the modal to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);
  
  // Handle escape key to close modal
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      // Prevent scrolling on the body when modal is open
      document.body.style.overflow = 'hidden';
    }
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4 animate-fade-in">
      <div 
        ref={modalRef}
        className="bg-[var(--card-bg)] border border-[var(--card-border)] rounded-xl overflow-hidden max-w-4xl w-full max-h-[90vh] shadow-2xl animate-scale-in flex flex-col"
      >
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-[var(--card-border)]">
          <h2 className="text-2xl font-bold text-[var(--primary-text)]">{project.title}</h2>
          <button 
            onClick={onClose}
            className="rounded-full p-2 hover:bg-[var(--secondary-bg)] text-[var(--secondary-text)] transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="overflow-y-auto">
          {/* Project Image */}
          <div className="relative h-60 sm:h-80">
            <img 
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Content */}
          <div className="p-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {project.tags.map((tag, index) => (
                <span 
                  key={index} 
                  className="bg-[var(--secondary-bg)] text-[var(--accent-color)] px-3 py-1 rounded-full text-xs"
                >
                  {tag}
                </span>
              ))}
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2 text-[var(--primary-text)]">Description</h3>
              <p className="text-[var(--secondary-text)]">{project.description}</p>
            </div>
            
            {/* Detailed sections - Note: These would be populated with real data in a production app */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2 text-[var(--primary-text)]">Key Features</h3>
              <ul className="list-disc list-inside text-[var(--secondary-text)]">
                <li>Feature 1: Lorem ipsum dolor sit amet</li>
                <li>Feature 2: Consectetur adipiscing elit</li>
                <li>Feature 3: Sed do eiusmod tempor incididunt</li>
              </ul>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2 text-[var(--primary-text)]">Technologies Used</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {project.tags.map((tech, index) => (
                  <div key={index} className="flex items-center gap-2 text-[var(--secondary-text)]">
                    <span className="block w-2 h-2 bg-[var(--accent-color)] rounded-full"></span>
                    <span>{tech}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2 text-[var(--primary-text)]">Challenges & Solutions</h3>
              <p className="text-[var(--secondary-text)]">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor 
                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis 
                nostrud exercitation ullamco laboris.
              </p>
            </div>
          </div>
        </div>
        
        {/* Footer with links */}
        <div className="mt-auto border-t border-[var(--card-border)] p-4 flex justify-between">
          <div>
            <span className="text-sm text-[var(--secondary-text)]">Project Type: {project.type}</span>
          </div>
          <div className="flex gap-4">
            <a 
              href={project.demoLink} 
              className="inline-block px-4 py-2 rounded-full bg-[var(--accent-gradient)] text-black font-medium text-sm transition-transform hover:-translate-y-1"
              target="_blank" 
              rel="noopener noreferrer"
            >
              View Demo
            </a>
            <a 
              href={project.codeLink} 
              className="inline-block px-4 py-2 rounded-full border border-[var(--card-border)] text-[var(--primary-text)] font-medium text-sm transition-transform hover:-translate-y-1"
              target="_blank" 
              rel="noopener noreferrer"
            >
              View Code
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}; 