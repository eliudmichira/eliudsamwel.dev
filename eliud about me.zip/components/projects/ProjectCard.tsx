import React from 'react';
import { ProjectCardProps } from '../../types';

interface ProjectCardComponentProps extends ProjectCardProps {
  onClick: () => void;
}

export const ProjectCard: React.FC<ProjectCardComponentProps> = ({
  title,
  description,
  image,
  tags,
  demoLink,
  codeLink,
  category,
  type,
  onClick
}) => {
  // Truncate description if it's too long
  const truncateDescription = (text: string, maxLength: number = 120) => {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  return (
    <div 
      className="group project-card bg-[var(--card-bg)] rounded-2xl overflow-hidden border border-[var(--card-border)] transition-all duration-300 ease-out hover:-translate-y-2 hover:scale-[1.03] hover:shadow-[var(--card-glow)] cursor-pointer animate-slide-in-bottom"
      data-category={category} 
      data-type={type}
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-[200px] object-cover transition-transform duration-700 ease-out group-hover:scale-110" 
        />
        <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
        <div className="absolute top-2 right-2 bg-[var(--card-bg)] px-3 py-1 rounded-full text-xs font-medium text-[var(--primary-text)] border border-[var(--card-border)]">
          {type}
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-wrap mb-4">
          {tags.slice(0, 4).map((tag: string, index: number) => (
            <span 
              key={index} 
              className="bg-[var(--secondary-bg)] text-[var(--accent-color)] px-3 py-1 rounded-full text-xs mr-2 mb-2"
            >
              {tag}
            </span>
          ))}
          {tags.length > 4 && (
            <span className="bg-[var(--secondary-bg)] text-[var(--secondary-text)] px-3 py-1 rounded-full text-xs mr-2 mb-2">
              +{tags.length - 4} more
            </span>
          )}
        </div>
        
        <h3 className="text-xl font-bold mb-3 text-[var(--primary-text)] group-hover:text-[var(--accent-color)] transition-colors">
          {title}
        </h3>
        
        <p className="text-[var(--secondary-text)] mb-6 text-sm">
          {truncateDescription(description)}
        </p>
        
        <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-4 group-hover:translate-y-0 duration-300">
          <a 
            href={demoLink} 
            className="inline-block px-4 py-2 rounded-full bg-[var(--accent-gradient)] text-black font-medium text-sm transition-transform hover:-translate-y-1"
            target="_blank" 
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
          >
            Live Demo
          </a>
          <a 
            href={codeLink} 
            className="inline-block px-4 py-2 rounded-full border border-[var(--card-border)] text-[var(--primary-text)] font-medium text-sm transition-transform hover:-translate-y-1"
            target="_blank" 
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
          >
            GitHub
          </a>
        </div>
        
        <div className="mt-4 flex items-center text-[var(--secondary-text)] text-xs group-hover:opacity-0 transition-opacity duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
          Click to view details
        </div>
      </div>
    </div>
  );
}; 