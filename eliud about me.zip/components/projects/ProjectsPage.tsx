import React, { useState, useEffect, useRef } from 'react';
import { ProjectCardProps } from '../../types';
import { ProjectCard } from './ProjectCard';
import { ProjectDetailModal } from './ProjectDetailModal';

// Project data
const projectsData: ProjectCardProps[] = [
  {
    id: 'voting-system',
    title: 'Decentralized Voting System',
    description: 'A secure and transparent voting platform using Ethereum smart contracts, React frontend, and Python for off-chain storage. Features voter authentication with JWT, eligibility checks, and real-time vote counting.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=Blockchain+Voting',
    category: 'blockchain',
    type: 'web',
    tags: ['Solidity', 'Ethereum', 'React', 'Web3.js', 'JWT Auth'],
    demoLink: '#',
    codeLink: '#',
  },
  {
    id: 'uzakitu-dashboard',
    title: 'UzaKitu Analytics Dashboard',
    description: 'Redesigned reseller dashboard for better UX using D3.js for visual data analytics and customized KPIs. Helps small businesses track performance and make data-driven decisions.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=Analytics+Dashboard',
    category: 'react',
    type: 'web',
    tags: ['React', 'D3.js', 'Analytics', 'Dashboard'],
    demoLink: '#',
    codeLink: '#',
  },
  {
    id: 'uzakitu-tracking',
    title: 'UzaKitu Order Tracking',
    description: 'Integrated real-time order updates via WebSocket to reduce support queries and improve user satisfaction. Provides real-time status updates and notifications.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=Order+Tracking',
    category: 'websocket',
    type: 'web',
    tags: ['WebSocket', 'React', 'Node.js', 'Real-time'],
    demoLink: '#',
    codeLink: '#',
  },
  {
    id: 'tinypesa',
    title: 'TinyPesa Platform Enhancements',
    description: 'Contributed to mobile/web app improvements including UI optimization and bug fixing during internship at Neverest Ltd. Focused on improving the payment processing flow.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=Mobile+Payments',
    category: 'mobile',
    type: 'mobile',
    tags: ['Mobile App', 'Payments', 'UI/UX', 'Optimization'],
    demoLink: '#',
    codeLink: '#',
  },
  {
    id: 'portfolio',
    title: 'Personal Portfolio Website',
    description: 'Modern, responsive portfolio website built with React, TypeScript and Tailwind CSS. Features smooth animations, dark/light mode, and an interactive user experience.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=Portfolio+Site',
    category: 'react',
    type: 'web',
    tags: ['React', 'TypeScript', 'Tailwind CSS', 'Responsive'],
    demoLink: '#',
    codeLink: '#',
  },
  {
    id: 'e-learning',
    title: 'E-Learning Platform',
    description: 'A web-based learning management system that enables course creation, student enrollment, and progress tracking with interactive content delivery.',
    image: 'https://placehold.co/600x400/1a1a1a/cccccc?text=E-Learning+Platform',
    category: 'fullstack',
    type: 'web',
    tags: ['React', 'Node.js', 'MongoDB', 'Express'],
    demoLink: '#',
    codeLink: '#',
  }
];

// Filter button component
const FilterButton: React.FC<{
  label: string;
  filterKey?: string;
  filterType?: string;
  isActive: boolean;
  onClick: () => void;
  isSecondary?: boolean;
}> = ({ label, isActive, onClick, isSecondary = false }) => {
  return (
    <button
      className={`px-5 py-2 rounded-full border-2 transition-all duration-300 ease-out
        ${isSecondary ? 
          `border-[var(--secondary-text)] text-[var(--secondary-text)] hover:border-[var(--accent-color)]` : 
          `border-[var(--accent-color)] text-[var(--accent-color)]`}
        ${isActive ? 'bg-[var(--accent-gradient)] text-black border-transparent transform -translate-y-1' : ''}
        hover:bg-[var(--accent-gradient)] hover:text-black hover:transform hover:-translate-y-1`}
      onClick={onClick}
    >
      {label}
    </button>
  );
};

// Projects page component
export const ProjectsPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeType, setActiveType] = useState<string>('all');
  const [visibleProjects, setVisibleProjects] = useState<ProjectCardProps[]>(projectsData);
  const [selectedProject, setSelectedProject] = useState<ProjectCardProps | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Refs for animation
  const headerRef = useRef<HTMLDivElement>(null);
  const filtersRef = useRef<HTMLDivElement>(null);
  const projectsGridRef = useRef<HTMLDivElement>(null);
  
  // Filter categories and types
  const categories = [
    { key: 'all', label: 'All Projects' },
    { key: 'react', label: 'React' },
    { key: 'blockchain', label: 'Blockchain' },
    { key: 'websocket', label: 'WebSocket' },
    { key: 'mobile', label: 'Mobile' },
    { key: 'fullstack', label: 'Full Stack' },
  ];
  
  const types = [
    { key: 'all', label: 'All Types' },
    { key: 'web', label: 'Web Apps' },
    { key: 'mobile', label: 'Mobile Apps' },
    { key: 'api', label: 'APIs' },
    { key: 'design', label: 'UI/UX' },
  ];
  
  const openProjectModal = (project: ProjectCardProps) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };
  
  const closeProjectModal = () => {
    setIsModalOpen(false);
    setSelectedProject(null);
  };

  // Apply intersection observer for animations
  useEffect(() => {
    const elementsToObserve = [headerRef, filtersRef, projectsGridRef];
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    elementsToObserve.forEach((ref) => {
      if (ref.current) {
        ref.current.classList.add('opacity-0', 'translate-y-8', 'transition-all', 'duration-700', 'ease-out');
        observer.observe(ref.current);
      }
    });

    return () => observer.disconnect();
  }, []);

  // Filter projects
  useEffect(() => {
    const filtered = projectsData.filter((project) => {
      const categoryMatch = activeCategory === 'all' || project.category === activeCategory;
      const typeMatch = activeType === 'all' || project.type === activeType;
      const searchMatch = !searchTerm || 
        project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      return categoryMatch && typeMatch && searchMatch;
    });
    
    // Stagger the appearance of project cards
    setTimeout(() => {
      setVisibleProjects(filtered);
    }, 100);
    
  }, [activeCategory, activeType, searchTerm]);

  return (
    <div className="max-w-7xl mx-auto fade-in-up">
      {/* Header Section */}
      <div 
        ref={headerRef} 
        className="text-center mb-12"
      >
        <h1 className="text-4xl md:text-5xl font-extrabold mb-4">
          My <span className="bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-600 bg-clip-text text-transparent">Projects</span>
        </h1>
        <p className="text-[var(--secondary-text)] text-lg max-w-2xl mx-auto">
          Showcasing my latest work and creative solutions
        </p>
      </div>

      {/* Search & Filter Section */}
      <div 
        ref={filtersRef} 
        className="mb-12 space-y-6"
      >
        {/* Search input */}
        <div className="max-w-md mx-auto">
          <div className="relative">
            <input
              type="text"
              placeholder="Search projects..."
              className="w-full p-3 pl-10 rounded-lg bg-[var(--card-bg)] border border-[var(--card-border)] text-[var(--primary-text)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--secondary-text)]">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            {searchTerm && (
              <button 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--secondary-text)] hover:text-[var(--primary-text)]"
                onClick={() => setSearchTerm('')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </div>
        
        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-6">
          {categories.map((cat) => (
            <FilterButton
              key={cat.key}
              label={cat.label}
              isActive={activeCategory === cat.key}
              onClick={() => setActiveCategory(cat.key)}
            />
          ))}
        </div>
        
        {/* Type filters */}
        <div className="flex flex-wrap justify-center gap-3">
          {types.map((type) => (
            <FilterButton
              key={type.key}
              label={type.label}
              isActive={activeType === type.key}
              onClick={() => setActiveType(type.key)}
              isSecondary={true}
            />
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div 
        ref={projectsGridRef}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
      >
        {visibleProjects.length > 0 ? (
          visibleProjects.map((project, index) => (
            <ProjectCard 
              key={project.id} 
              {...project}
              onClick={() => openProjectModal(project)}
            />
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <div className="text-[var(--secondary-text)] text-xl mb-4">No projects match your filters</div>
            <button
              onClick={() => {
                setActiveCategory('all');
                setActiveType('all');
                setSearchTerm('');
              }}
              className="px-5 py-2 rounded-lg bg-[var(--accent-gradient)] text-black font-medium"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
      
      {/* Project count */}
      <div className="mt-8 text-center text-[var(--secondary-text)]">
        Showing {visibleProjects.length} of {projectsData.length} projects
      </div>
      
      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetailModal 
          project={selectedProject}
          isOpen={isModalOpen}
          onClose={closeProjectModal}
        />
      )}
    </div>
  );
};

export default ProjectsPage; 