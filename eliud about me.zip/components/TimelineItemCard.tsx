import React, { useRef } from 'react';
import { TimelineEvent } from '../types';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface TimelineItemCardProps {
  event: TimelineEvent;
  isOdd: boolean;
}

export const TimelineItemCard: React.FC<TimelineItemCardProps> = ({ event, isOdd }) => {
  const itemRef = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver<HTMLDivElement>(itemRef, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });

  // Enhanced hover effects with smoother transitions
  const cardHoverEffect = "hover:transform hover:translate-y-[var(--hover-lift)] hover:scale-[var(--hover-scale)] hover:shadow-[var(--card-glow)] hover:border-[var(--accent-color)] transition-all duration-300";
  
  // Desktop: Better alternating layout with distinct positioning
  const alignmentClasses = isOdd 
    ? 'md:ml-0 md:mr-auto md:items-end' 
    : 'md:mr-0 md:ml-auto md:items-start';
  
  const contentPositionClasses = isOdd
    ? 'md:pr-8 md:right-[50%] md:translate-x-[-20px]'
    : 'md:pl-8 md:left-[50%] md:translate-x-[20px]';
  
  const textAlignClasses = isOdd ? 'md:text-right' : 'md:text-left';
  
  // Enhanced arrow styles for better visual connection to timeline
  const arrowClasses = isOdd 
    ? `md:right-[-16px] md:border-l-[16px] md:border-l-[var(--card-bg)] group-hover:md:border-l-[var(--accent-color)]` 
    : `md:left-[-16px] md:border-r-[16px] md:border-r-[var(--card-bg)] group-hover:md:border-r-[var(--accent-color)]`;

  // Animation direction based on card position
  const animationClass = isOdd
    ? isVisible ? 'opacity-100 md:translate-x-0 translate-y-0 delay-150' : 'opacity-0 md:translate-x-12 translate-y-16'
    : isVisible ? 'opacity-100 md:translate-x-0 translate-y-0 delay-150' : 'opacity-0 md:translate-x-[-12px] translate-y-16';

  return (
    <div 
      ref={itemRef}
      className={`relative flex mb-24 sm:mb-28 min-h-[200px] transition-all duration-700 ease-out
                  ${animationClass}`}
    >
      {/* Dot on the timeline line specific to this item (Visible on all screen sizes) */}
      <div className={`absolute left-4 md:left-1/2 top-7 w-6 h-6 bg-[var(--accent-gradient)] rounded-full 
                       transform md:-translate-x-1/2 z-[5] border-4 border-[var(--primary-bg)]
                       transition-all duration-300 ease-out group-hover:scale-125 shadow-[var(--dot-glow)]`}
      ></div>

      {/* Content Card */}
      <div 
        className={`group bg-[var(--card-bg)] rounded-[var(--border-radius-lg)] p-6 sm:p-8 
                   w-[calc(100%-3.5rem)] md:w-[45%] border border-[var(--card-border)] shadow-[var(--card-shadow)]
                   relative transition-all duration-400 ease-out ${cardHoverEffect}
                   ml-12 md:ml-0 md:absolute ${contentPositionClasses}
                   text-left ${textAlignClasses}`}
      >
        {/* Arrow for Desktop - Better positioned based on side */}
        <div className={`hidden md:block absolute top-8 w-0 h-0 border-[16px] border-transparent transition-colors duration-300 ease-out
                       ${arrowClasses}`}
        ></div>
        {/* Arrow for Mobile (always points left from card to line) */}
        <div className={`block md:hidden absolute top-8 left-[-16px] w-0 h-0 border-[16px] border-transparent 
                       border-r-[16px] border-r-[var(--card-bg)] group-hover:border-r-[var(--accent-color)]
                       transition-colors duration-300 ease-out`}>
        </div>

        <div className={`role-icon w-14 h-14 sm:w-16 sm:h-16 bg-[var(--accent-gradient)] rounded-xl 
                        flex items-center justify-center mb-5 text-2xl sm:text-3xl shadow-lg
                        ${isOdd ? 'md:ml-auto' : 'md:mr-auto'} transition-transform duration-300 ease-out
                        group-hover:scale-110`}>
          {event.icon}
        </div>

        <h3 className="text-[clamp(1.4rem,3vw,1.75rem)] sm:text-[clamp(1.6rem,3vw,2rem)] font-bold mb-3 text-[var(--primary-text)]
                       transition-colors duration-300 group-hover:text-[var(--accent-color)]">
          {event.title}
        </h3>
        
        <p className="text-[var(--secondary-text)] leading-relaxed mb-6 text-sm sm:text-base">
          {event.description}
        </p>

        {event.achievement && (
          <div className={`bg-[var(--accent-color)]/10 border-l-4 md:border-l-0 
                          ${isOdd ? 'md:border-r-4' : 'md:border-l-4'} border-[var(--accent-color)] 
                          p-4 sm:p-5 mt-5 rounded-r-lg md:rounded-r-none 
                          ${isOdd ? 'md:rounded-l-lg' : 'md:rounded-r-lg'} 
                          text-left ${isOdd ? 'md:text-right' : 'md:text-left'} 
                          backdrop-blur-sm transition-all duration-300 ease-out
                          group-hover:bg-[var(--accent-color)]/15 group-hover:shadow-inner`}>
            <div className="font-bold text-[var(--accent-color)] mb-2 text-base sm:text-lg">
              {event.achievement.title}
            </div>
            <p className="text-[var(--secondary-text)]/90 text-xs sm:text-sm leading-normal !mb-0">
              {event.achievement.text}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
