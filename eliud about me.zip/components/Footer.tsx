import React from 'react';

interface FooterProps {
  onNavLinkClick: (pageId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavLinkClick }) => {
  const handleInternalLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, pageId: string) => {
    e.preventDefault();
    onNavLinkClick(pageId);
  };

  return (
    <footer className="bg-black py-12 sm:py-16 text-[var(--secondary-text)]">
      <div className="container mx-auto px-4 sm:px-6 max-w-7xl">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="mb-8 md:mb-0">
            <a 
              href="#About"
              onClick={(e) => handleInternalLinkClick(e, 'About')}
              className="flex items-center justify-center md:justify-start space-x-1.5 group"
            >
              <span className="text-2xl sm:text-3xl font-extrabold text-white group-hover:text-[var(--accent-color)] transition-colors">Eliud</span>
              <span className="text-2xl sm:text-3xl font-extrabold gradient-text">Samwel</span>
            </a>
            <p className="text-gray-500 mt-2 text-sm sm:text-base">
              Frontend Developer & UX Designer
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center md:justify-end gap-x-6 gap-y-3">
            <a href="#About" onClick={(e) => handleInternalLinkClick(e, 'About')} className="text-gray-400 hover:text-[var(--accent-color)] transition font-medium text-sm sm:text-base">About</a>
            <a href="#Resume" onClick={(e) => handleInternalLinkClick(e, 'Resume')} className="text-gray-400 hover:text-[var(--accent-color)] transition font-medium text-sm sm:text-base">Resume</a>
            <a href="#Projects" onClick={(e) => handleInternalLinkClick(e, 'Projects')} className="text-gray-400 hover:text-[var(--accent-color)] transition font-medium text-sm sm:text-base">Projects</a>
            <a href="#Contact" onClick={(e) => handleInternalLinkClick(e, 'Contact')} className="text-gray-400 hover:text-[var(--accent-color)] transition font-medium text-sm sm:text-base">Contact</a>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 sm:mt-12 pt-8 sm:pt-10 flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <p className="text-gray-500 text-xs sm:text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Eliud Samwel Michira. All rights reserved.
          </p>
          
          <div className="flex space-x-5 sm:space-x-6">
            <a href="https://github.com/eliudmichira" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[var(--accent-color)] transition" aria-label="GitHub Profile">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
              </svg>
            </a>
            <a href="https://www.linkedin.com/in/eliud-samwel-72b8622b3" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[var(--accent-color)] transition" aria-label="LinkedIn Profile">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
              </svg>
            </a>
            <a href="mailto:eliudmichira7@gmail.com" className="text-gray-400 hover:text-[var(--accent-color)] transition" aria-label="Email Eliud Michira">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-.4 4.25l-7.07 4.42c-.32.2-.74.2-1.06 0L4.4 8.25V6.5l7.6 4.75 7.6-4.75v1.75z"/></svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};