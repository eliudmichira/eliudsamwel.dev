import React, { useEffect, useRef } from 'react';
import '../styles/theme.css';

interface ThemeToggleProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ theme, toggleTheme }) => {
  const moonRef = useRef<HTMLDivElement>(null);
  const skyRef = useRef<HTMLDivElement>(null);
  const cloudsRef = useRef<HTMLDivElement[]>([]);
  
  useEffect(() => {
    const updateElements = () => {
      // Update moon position
      if (moonRef.current) {
        if (theme === 'dark') {
          moonRef.current.style.right = '14px';
        } else {
          moonRef.current.style.right = '-40px';
        }
      }
      
      // Update sky color
      if (skyRef.current) {
        skyRef.current.style.background = theme === 'dark' 
          ? 'linear-gradient(135deg, #0f2027, #203a43, #2c5364)' 
          : 'linear-gradient(135deg, #89f7fe, #66a6ff)';
      }
      
      // Animate clouds
      cloudsRef.current.forEach((cloud, index) => {
        if (cloud) {
          cloud.style.transform = theme === 'dark' 
            ? `translateX(${20 * (index + 1)}px) scale(0.8)` 
            : `translateX(0) scale(1)`;
          cloud.style.opacity = theme === 'dark' ? '0.3' : '0.8';
        }
      });
    };
    
    updateElements();
  }, [theme]);
  
  // Set up cloud refs
  const setCloudRef = (element: HTMLDivElement | null, index: number) => {
    if (element) {
      cloudsRef.current[index] = element;
    }
  };

  return (
    <button 
      onClick={toggleTheme}
      className="theme-toggle"
      aria-label="Toggle theme"
    >
      <div className="theme-toggle-inner" ref={skyRef}>
        {/* Clouds */}
        <div 
          ref={(el) => setCloudRef(el, 0)}
          className="cloud cloud-1"
          style={{
            position: 'absolute',
            width: '16px',
            height: '8px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '8px',
            top: '12px',
            left: '10px',
            zIndex: 3,
            opacity: theme === 'dark' ? '0.3' : '0.8',
            transform: theme === 'dark' ? 'translateX(20px) scale(0.8)' : 'translateX(0) scale(1)',
            transition: 'all 0.5s ease',
            pointerEvents: 'none',
          }}
        ></div>
        
        <div 
          ref={(el) => setCloudRef(el, 1)}
          className="cloud cloud-2"
          style={{
            position: 'absolute',
            width: '20px',
            height: '10px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '10px',
            top: '38px',
            left: '18px',
            zIndex: 3,
            opacity: theme === 'dark' ? '0.3' : '0.8',
            transform: theme === 'dark' ? 'translateX(40px) scale(0.8)' : 'translateX(0) scale(1)',
            transition: 'all 0.6s ease',
            pointerEvents: 'none',
          }}
        ></div>
        
        <div 
          ref={(el) => setCloudRef(el, 2)}
          className="cloud cloud-3"
          style={{
            position: 'absolute',
            width: '14px',
            height: '7px',
            background: 'rgba(255, 255, 255, 0.8)',
            borderRadius: '7px',
            top: '25px',
            left: '35px',
            zIndex: 3,
            opacity: theme === 'dark' ? '0.3' : '0.8',
            transform: theme === 'dark' ? 'translateX(60px) scale(0.8)' : 'translateX(0) scale(1)',
            transition: 'all 0.7s ease',
            pointerEvents: 'none',
          }}
        ></div>
        
        {/* Sun */}
        <div 
          className="sun"
          style={{
            opacity: theme === 'dark' ? 0.5 : 1,
            transition: 'opacity 0.5s ease',
          }}
        ></div>
        
        {/* Moon */}
        <div 
          className="moon"
          ref={moonRef}
        ></div>
      </div>
    </button>
  );
};

export default ThemeToggle;