
import React from 'react';

interface ProgressBarProps {
  progress: number; // 0 to 100
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress }) => {
  return (
    <div 
      className="w-full max-w-2xl mx-auto mb-12 sm:mb-16 
                 bg-[var(--card-bg)] dark:bg-[var(--card-bg)] 
                 rounded-full p-1.5 border border-[var(--card-border)] dark:border-[var(--card-border)] 
                 shadow-inner"
      title="Timeline Scroll Progress"
    >
      <div 
        className="h-3 bg-[var(--accent-gradient)] rounded-full relative transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-md"
        style={{ width: `${progress}%` }}
      >
        {progress > 1 && progress < 99 && ( 
             <div className="absolute right-[-6px] top-1/2 transform -translate-y-1/2 w-6 h-6 bg-[var(--accent-gradient)] rounded-full 
             border-3 border-[var(--primary-bg)] dark:border-[var(--primary-bg)] 
             shadow-[var(--dot-glow)] animate-pulse" style={{animationDuration: '1.5s'}}></div>
        )}
      </div>
    </div>
  );
};
