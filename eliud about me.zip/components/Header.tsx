import React, { useState, useEffect, useRef } from 'react';
import { NavLinkItem } from '../types';

interface HeaderProps {
  navLinks: NavLinkItem[];
  onNavLinkClick: (pageId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ navLinks, onNavLinkClick }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    document.body.style.overflow = !isMobileMenuOpen ? 'hidden' : '';
  };
  
  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
    document.body.style.overflow = '';
  };

  const handleLinkClick = (pageId: string) => {
    onNavLinkClick(pageId);
    closeMobileMenu();
  };

  useEffect(() => { // Mobile menu click outside
    const handleClickOutside = (event: MouseEvent) => {
      if (
        mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node) &&
        menuButtonRef.current && !menuButtonRef.current.contains(event.target as Node) &&
        isMobileMenuOpen
      ) {
        closeMobileMenu();
      }
    };
    if (isMobileMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobileMenuOpen]);
  
  // Classes for the main navigation bar (contact.html style)
  const navBarClasses = `fixed top-6 sm:top-8 left-1/2 transform -translate-x-1/2 z-[1000] 
                         bg-[var(--card-bg)]/80 dark:bg-[var(--card-bg)]/80 
                         backdrop-blur-[var(--blur-amount)]
                         border border-[var(--card-border)] dark:border-[var(--card-border)] 
                         rounded-full py-2 px-3 sm:py-2.5 sm:px-4 shadow-xl transition-all duration-300 ease-linear`;

  return (
    <>
      {/* Desktop Navigation (contact.html style) */}
      <nav className={`${navBarClasses} hidden lg:block`}>
        <ul className="flex list-none items-center gap-1 sm:gap-1.5">
          {navLinks.map((link) => (
            <li key={link.pageId}>
              <a
                href={link.href}
                onClick={(e) => { e.preventDefault(); handleLinkClick(link.pageId); }}
                className={`block px-4 sm:px-6 py-2 sm:py-2.5 rounded-full transition-all duration-300 ease-linear text-xs sm:text-sm font-medium relative
                           ${link.current
                               ? 'text-black dark:text-black' 
                               : 'text-[var(--primary-text)] dark:text-[var(--primary-text)] hover:bg-white/10 dark:hover:bg-white/5 hover:text-[var(--accent-color)] dark:hover:text-[var(--accent-color)]'
                           } focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent-color)]`}
                aria-current={link.current ? 'page' : undefined}
              >
                {link.current && (
                  <span className="absolute inset-0 rounded-full bg-[var(--accent-gradient)] shadow-lg z-[-1]"></span>
                )}
                <span className="relative z-10">{link.name}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* Mobile Navigation Header (Logo and Toggle Button) - Appears above content */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-[1000] p-4 flex justify-between items-center bg-[var(--primary-bg)]/90 dark:bg-[var(--primary-bg)]/90 backdrop-blur-md shadow-lg border-b border-[var(--card-border)] dark:border-[var(--card-border)]">
        <a
            href="#About"
            onClick={(e) => { e.preventDefault(); handleLinkClick('About');}}
            className={`text-xl font-extrabold text-[var(--primary-text)] transition-colors duration-300 ease-linear`}
          >
            Eliud
            <span className="gradient-text">.dev</span>
        </a>
        <button
            ref={menuButtonRef}
            id="mobile-menu-button"
            className="text-[var(--primary-text)] dark:text-[var(--primary-text)] p-2"
            onClick={toggleMobileMenu}
            aria-controls="mobile-menu"
            aria-expanded={isMobileMenuOpen}
            aria-label="Toggle navigation menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
        </button>
      </header>

      {/* Mobile Menu - Full Screen Overlay */}
      <div
        id="mobile-menu"
        ref={mobileMenuRef}
        className={`fixed inset-0 bg-[var(--primary-bg)]/95 dark:bg-[var(--primary-bg)]/95 backdrop-blur-xl z-[999] 
                   transform transition-transform duration-300 ease-in-out lg:hidden
                   ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="container h-full flex flex-col pt-24"> {/* Increased padding top for mobile header space */}
          <div className="flex flex-col items-center justify-center flex-grow space-y-5">
            <ul className="flex flex-col space-y-5 w-full px-4">
              {navLinks.map((link) => (
                <li key={link.pageId}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); handleLinkClick(link.pageId); }}
                    className={`block w-full px-6 py-3.5 rounded-xl text-center transition-all duration-300 ease-linear text-base font-semibold
                               ${link.current
                                   ? 'bg-[var(--accent-gradient)] text-black dark:text-black shadow-lg'
                                   : 'text-[var(--primary-text)] dark:text-[var(--primary-text)] bg-[var(--secondary-bg)] dark:bg-[var(--secondary-bg)] hover:brightness-125'
                               } focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent-color)]`}
                    aria-current={link.current ? 'page' : undefined}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};