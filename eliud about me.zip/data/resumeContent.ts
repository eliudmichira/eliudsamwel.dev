import React from 'react';
import { ResumeData } from '../types';

// SVG Icon Components
// FIX: Convert JSX to React.createElement to resolve parsing and type errors, and explicitly type return as JSX.Element
const LocationIcon = (props: React.SVGProps<SVGSVGElement>): React.ReactElement => (
  React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", ...props },
    React.createElement("path", { d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" })
  )
);

// FIX: Convert JSX to React.createElement to resolve parsing and type errors
const EmailIcon = (props: React.SVGProps<SVGSVGElement>): React.ReactElement => (
  React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", ...props },
    React.createElement("path", { d: "M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" })
  )
);

// FIX: Convert JSX to React.createElement to resolve parsing and type errors
const PhoneIcon = (props: React.SVGProps<SVGSVGElement>): React.ReactElement => (
  React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", ...props },
    React.createElement("path", { d: "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" })
  )
);

// FIX: Convert JSX to React.createElement to resolve parsing and type errors
const LinkedInIcon = (props: React.SVGProps<SVGSVGElement>): React.ReactElement => (
  React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", ...props },
    React.createElement("path", { d: "M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z" })
  )
);


export const resumeData: ResumeData = {
  fullName: "Eliud Samwel",
  accentName: "Michira",
  jobTitle: "Software Developer & Tech Innovator",
  location: {
    icon: LocationIcon,
    text: "Kenya (Remote/Onsite opportunities welcome)"
  },
  contactInfo: [
    { icon: EmailIcon, text: "eliudmichira7@gmail.com", href: "mailto:eliudmichira7@gmail.com", ariaLabel: "Email Eliud Michira" },
    { icon: PhoneIcon, text: "+254 705 893 137", href: "tel:+254705893137", ariaLabel: "Call Eliud Michira" },
    { icon: LinkedInIcon, text: "linkedin.com/in/eliudmichira", href: "https://www.linkedin.com/in/eliudmichira", ariaLabel: "Eliud Michira's LinkedIn Profile"}
  ],
  professionalSummary: "I'm a passionate software developer from Kenya, focused on building efficient, scalable, and user-friendly applications. My experience spans web development, mobile platforms, and decentralized systems, with a strong emphasis on solving real-world problems using innovative tech solutions.",
  coreCompetencies: {
    skills: [
      { name: "JavaScript", level: 85 },
      { name: "Solidity", level: 75 },
      { name: "Python", level: 70 },
      { name: "SQL", level: 80 },
      { name: "React.js", level: 90 },
      { name: "Node.js", level: 85 },
      { name: "Express.js", level: 80 },
      { name: "Ethereum", level: 70 },
      { name: "Web3.js", level: 75 },
      { name: "PostgreSQL", level: 65 },
      { name: "MongoDB", level: 75 },
      { name: "REST APIs", level: 90 }
    ],
    detailed: [
      { category: "Languages", items: "JavaScript, Solidity, Python, SQL" },
      { category: "Frontend", items: "HTML, CSS, React.js" },
      { category: "Backend", items: "Node.js, Express.js, Flask" },
      { category: "Blockchain", items: "Ethereum, Truffle, Web3.js" },
      { category: "Database", items: "PostgreSQL, MongoDB" },
      { category: "Tools", items: "Git, VS Code, Postman, Docker" },
      { category: "Other", items: "JWT Auth, WebSocket, D3.js, REST APIs" }
    ]
  },
  experience: [
    {
      role: "Software Developer Intern",
      company: "Neverest Ltd under TAWA INNOVATE LIMITED",
      dates: "June 2023 – December 2023",
      responsibilities: [
        "Contributed to the development of digital platforms like TinyPesa (mobile payment solution) and UzaKitu (e-commerce system for small businesses)",
        "Improved usability, system performance, and analytics-driven decision-making",
        "Redesigned reseller dashboard for better UX using D3.js for visual data analytics",
        "Integrated real-time order updates via WebSocket to reduce support queries and improve user satisfaction"
      ]
    },
    {
      role: "Blockchain Developer",
      company: "Freelance",
      dates: "January 2023 – Present",
      responsibilities: [
        "Developed a Decentralized Voting Management System using Ethereum smart contracts",
        "Implemented voter authentication with JWT and eligibility checks via smart contract",
        "Created real-time vote counting system with WebSocket integration for instant updates",
        "Focused on security and transparency in digital election processes"
      ]
    },
    {
      role: "Web Development Specialist",
      company: "Self-employed",
      dates: "January 2022 – Present",
      responsibilities: [
        "Designed and developed responsive, user-friendly websites for various clients using modern web technologies",
        "Built scalable web applications with React.js, Node.js, and various database solutions",
        "Optimized website performance for speed and search engine visibility",
        "Utilized Git for version control and project management"
      ]
    }
  ],
  education: [
    {
      degree: "Bachelor of Science in Business Computing",
      institution: "Jomo Kenyatta University of Agriculture and Technology",
      dates: "September 2021 – Present"
    },
    {
      degree: "Kenya Certificate of Secondary Education",
      institution: "Starehe Boys Centre",
      dates: "Completed"
    }
  ],
  professionalDevelopment: [
    { item: "Blockchain Developer Certification", source: "Ethereum Foundation", date: "June 2023" },
    { item: "Full Stack Web Development", source: "Udacity", date: "March 2022" },
    { item: "Self-Directed Learning", source: "Continuously updating skills through online resources, tutorials, and industry publications" }
  ],
  references: [
    {
      name: "Available upon request",
      title: "",
      contacts: []
    }
  ]
};
