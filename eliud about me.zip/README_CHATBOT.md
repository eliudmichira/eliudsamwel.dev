# Gemini AI Chatbot Integration

This project includes a chatbot powered by Google's Gemini AI. Follow these instructions to set up and customize the chatbot for your portfolio.

## Setup Instructions

### 1. Get a Gemini API Key

1. Visit [Google AI Studio](https://ai.google.dev/) and sign up or log in
2. Create a new API key from the API Keys section
3. Copy your API key for the next step

### 2. Configure the API Key

Open `config/chatConfig.ts` and replace the placeholder API key with your actual Gemini API key:

```typescript
// Replace this with your actual Gemini API key
export const GEMINI_API_KEY = "YOUR_GEMINI_API_KEY";
```

**Note:** In a production environment, you should use environment variables instead of hardcoding the API key in your source code.

## Features

- Real-time chat with Gemini AI
- Floating chat button that stays accessible throughout the site
- Mobile-responsive design
- Typing indicators and loading states
- Persistent chat history during the session

## Customization

### Changing the Chat UI

You can customize the appearance of the chatbot by modifying the CSS in `styles/chatbot.css`. The main elements are:

- `.chatbot-container` - The wrapper for the entire chatbot
- `.chatbot-toggle` - The floating button that opens/closes the chat
- `.chatbot-window` - The chat window itself
- `.chatbot-message` - Individual message bubbles

### Modifying Chatbot Behavior

To change the chatbot's behavior, edit the `config/chatConfig.ts` file:

```typescript
export const chatConfig = {
  initialMessage: "Custom welcome message here",
  modelName: "gemini-pro", // or another Gemini model
  apiVersion: "v1beta",
  maxTokens: 2048, // Adjust response length
};
```

## Implementation Details

The chatbot is implemented as a React component in `components/chat/ChatBot.tsx`. It uses:

1. React hooks for state management
2. Google's Gemini API for AI responses
3. CSS transitions for smooth animations
4. Responsive design that works on all screen sizes

## Troubleshooting

If you encounter issues with the chatbot:

- Ensure your API key is correctly set in the configuration
- Check browser console for any errors
- Verify your internet connection is stable
- Confirm you're not exceeding API rate limits 