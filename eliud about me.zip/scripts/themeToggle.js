/**
 * Standalone Theme Toggle Script
 * This script creates a theme toggle button that is immune to styling conflicts
 */

(function() {
  // Function to initialize theme based on localStorage or system preference
  function initializeTheme() {
    try {
      const savedTheme = localStorage.getItem('theme');
      
      if (savedTheme === 'dark') {
        document.documentElement.classList.remove('light');
        document.documentElement.classList.add('dark');
        document.documentElement.setAttribute('data-theme', 'dark');
        document.documentElement.style.colorScheme = 'dark';
        document.body.style.backgroundColor = '#0a0a0a';
        document.body.style.color = '#ffffff';
      } else if (savedTheme === 'light') {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.style.colorScheme = 'light';
        document.body.style.backgroundColor = '#0a0a0a';
        document.body.style.color = '#ffffff';
      } else {
        // Use system preference if no saved theme
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
          document.documentElement.classList.add('dark');
          document.documentElement.setAttribute('data-theme', 'dark');
          document.documentElement.style.colorScheme = 'dark';
          document.body.style.backgroundColor = '#0a0a0a';
          document.body.style.color = '#ffffff';
        } else {
          document.documentElement.classList.add('light');
          document.documentElement.setAttribute('data-theme', 'light');
          document.documentElement.style.colorScheme = 'light';
          document.body.style.backgroundColor = '#0a0a0a';
          document.body.style.color = '#ffffff';
        }
      }
      
      console.log('Theme initialized to:', document.documentElement.className);
    } catch (err) {
      console.error('Error initializing theme:', err);
    }
  }
  
  // Function to create and insert the theme toggle
  function createThemeToggle() {
    try {
      console.log('Creating theme toggle');
      
      // First remove any existing theme toggles to avoid duplicates
      document.querySelectorAll('.theme-toggle, #theme-toggle, .theme-toggle-v2').forEach(el => {
        try {
          el.remove();
        } catch (err) {
          console.error('Error removing existing toggle:', err);
        }
      });
      
      // Create the toggle container
      const toggle = document.createElement('div');
      
      // Add extensive inline styles to ensure visibility
      toggle.setAttribute('style', `
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        width: 60px !important;
        height: 60px !important;
        z-index: 999999 !important;
        cursor: pointer !important;
        display: block !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto !important;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.5) !important;
        border-radius: 50% !important;
        background: linear-gradient(135deg, #1a1e3f, #2c3e50) !important;
        overflow: hidden !important;
      `);
      
      // Set id and class for easier selection
      toggle.id = 'theme-toggle-v2';
      toggle.className = 'theme-toggle-v2';
      
      // Check current theme
      const isDarkTheme = document.documentElement.classList.contains('dark');
      
      // Create toggle inner HTML
      toggle.innerHTML = `
        <div class="sun-v2" style="
          position: absolute !important;
          width: 32px !important;
          height: 32px !important;
          background: #FFD700 !important;
          border-radius: 50% !important;
          top: 14px !important;
          left: 14px !important;
          box-shadow: 0 0 15px rgba(255, 215, 0, 0.7) !important;
          z-index: 1 !important;
          display: block !important;
          opacity: ${isDarkTheme ? '0.7' : '1'} !important;
          pointer-events: none !important;
        "></div>
        <div class="moon-v2" style="
          position: absolute !important;
          width: 32px !important;
          height: 32px !important;
          background: #121621 !important;
          border-radius: 50% !important;
          top: 14px !important;
          right: ${isDarkTheme ? '14px' : '-40px'} !important;
          transition: all 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55) !important;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.7) !important;
          z-index: 2 !important;
          display: block !important;
          pointer-events: none !important;
        "></div>
      `;
      
      // Add toggle to the document body
      document.body.appendChild(toggle);
      
      // Add click event listener
      toggle.addEventListener('click', function() {
        console.log('Theme toggle clicked');
        const isCurrentlyLight = document.documentElement.classList.contains('light');
        
        if (isCurrentlyLight) {
          // Switch to dark theme
          console.log('Before change - Classes:', document.documentElement.className);
          document.documentElement.classList.remove('light');
          document.documentElement.classList.add('dark');
          document.documentElement.setAttribute('data-theme', 'dark');
          localStorage.setItem('theme', 'dark');
          
          // Force repaint by accessing offsetHeight
          document.body.offsetHeight;
          
          // Apply direct styling for debugging
          document.documentElement.style.colorScheme = 'dark';
          document.body.style.backgroundColor = '#0a0a0a';
          document.body.style.color = '#ffffff';
          
          // Update toggle appearance
          this.querySelector('.sun-v2').style.opacity = '0.7';
          this.querySelector('.moon-v2').style.right = '14px';
          console.log('Changed to dark theme - Classes now:', document.documentElement.className);
          
          // Dispatch custom event
          document.dispatchEvent(new CustomEvent('themeChanged', { detail: { theme: 'dark' } }));
        } else {
          // Switch to light theme
          console.log('Before change - Classes:', document.documentElement.className);
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
          document.documentElement.setAttribute('data-theme', 'light');
          localStorage.setItem('theme', 'light');
          
          // Force repaint by accessing offsetHeight
          document.body.offsetHeight;
          
          // Apply direct styling for debugging
          document.documentElement.style.colorScheme = 'light';
          document.body.style.backgroundColor = '#0a0a0a';
          document.body.style.color = '#ffffff';
          
          // Update toggle appearance
          this.querySelector('.sun-v2').style.opacity = '1';
          this.querySelector('.moon-v2').style.right = '-40px';
          console.log('Changed to light theme - Classes now:', document.documentElement.className);
          
          // Dispatch custom event
          document.dispatchEvent(new CustomEvent('themeChanged', { detail: { theme: 'light' } }));
        }
      });
      
      console.log('Theme toggle created successfully');
    } catch (err) {
      console.error('Error creating theme toggle:', err);
    }
  }
  
  // Function to ensure the toggle exists
  function ensureToggleExists() {
    if (!document.getElementById('theme-toggle-v2')) {
      createThemeToggle();
    }
  }
  
  // Initialize theme and create toggle on document load
  window.addEventListener('load', function() {
    initializeTheme();
    createThemeToggle();
    
    // Safety checks to ensure toggle exists
    setTimeout(ensureToggleExists, 500);
    setTimeout(ensureToggleExists, 1000);
    setTimeout(ensureToggleExists, 2000);
  });
  
  // Create toggle immediately if document is already loaded
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initializeTheme();
    createThemeToggle();
  }
  
  // Monitor for DOM changes that might remove our toggle
  let toggleRemovalCheck = setInterval(function() {
    if (!document.getElementById('theme-toggle-v2') && document.body) {
      console.log('Toggle was removed, adding it back');
      createThemeToggle();
    }
  }, 2000);
})(); 