import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { ThemeToggle } from './components/ThemeToggle';
import { PageHeaderSection } from './components/PageHeaderSection';
import { StatsSection } from './components/StatsSection';
import { TimelineSection } from './components/TimelineSection';
import { Footer } from './components/Footer';
import { FloatingActionButton } from './components/FloatingActionButton';
import { useThemeManager } from './hooks/useThemeManager';
import { NavLinkItem, TimelineEvent } from './types';
import { ResumePage } from './components/resume/ResumePage';
import { ContactPage } from './components/contact/ContactPage';
import { ProjectsPage } from './components/projects/ProjectsPage';
import { BlogPage } from './components/blog/BlogPage';
import { ThemeToggleShowcasePage } from './components/showcase/ThemeToggleShowcasePage';
import { ChatBot } from './components/chat/ChatBot';
import './styles/theme.css';
import './styles/animations.css';

declare var particlesJS: any; 
declare var pJSDom: any; 

const initialNavLinksData: Omit<NavLinkItem, 'current'>[] = [
    { name: 'About', pageId: 'About', href: '#about' }, 
    { name: 'Resume', pageId: 'Resume', href: '#resume' },
    { name: 'Projects', pageId: 'Projects', href: '#projects' },
    { name: 'Blog', pageId: 'Blog', href: '#blog' },
    { name: 'Contact', pageId: 'Contact', href: '#contact' },
    { name: 'Toggles', pageId: 'Toggles', href: '#toggles' },
];

const timelineEventsData: TimelineEvent[] = [
    {
        id: 'bio',
        category: 'bio',
        icon: '👤',
        title: 'About Me',
        description: "I'm a passionate software developer from Kenya, focused on building efficient, scalable, and user-friendly applications. My experience spans web development, mobile platforms, and decentralized systems, with a strong emphasis on solving real-world problems using innovative tech solutions.",
        achievement: {
            title: '🌟 Core Values',
            text: 'Innovation through simplicity, clean and maintainable code, data-driven decision-making, ethical and user-focused development.',
        },
    },
    {
        id: 'experience',
        category: 'experience',
        icon: '💼',
        title: 'Professional Experience',
        description: "I interned at Neverest Ltd under TAWA INNOVATE LIMITED, where I contributed to the development of digital platforms like TinyPesa (a mobile payment solution) and UzaKitu (an e-commerce system for small businesses). My work improved usability, system performance, and analytics-driven decision-making.",
        achievement: {
            title: '🚀 Key Contributions',
            text: 'Enhanced user interfaces, integrated real-time updates, and built analytics dashboards for better business intelligence.',
        },
    },
    {
        id: 'projects',
        category: 'projects',
        icon: '🛠️',
        title: 'Notable Projects',
        description: "I'm the developer of a Decentralized Voting Management System, designed to promote trust and transparency in digital elections using blockchain technology. The system features voter authentication with JWT, eligibility checks via smart contract, real-time vote counting, and WebSocket integration for instant updates.",
        achievement: {
            title: '🏆 Project Impact',
            text: 'Created secure, transparent voting solutions that enhance trust in digital democratic processes.',
        },
    },
    {
        id: 'skills',
        category: 'skills',
        icon: '💻',
        title: 'Tech Stack & Skills',
        description: "My technical toolkit includes: Languages (JavaScript, Solidity, Python, SQL), Frontend (HTML, CSS, React.js), Backend (Node.js, Express.js, Flask), Blockchain (Ethereum, Truffle, Web3.js), Database (PostgreSQL, MongoDB), and various development tools.",
        achievement: {
            title: '📚 Continuous Learning',
            text: 'Constantly expanding my skills through self-directed learning and practical application in diverse projects.',
        },
    },
    {
        id: 'future',
        category: 'future',
        icon: '🔮',
        title: 'Looking Forward',
        description: "I'm passionate about building solutions that make a real difference. I'm particularly interested in the intersection of blockchain and traditional web technologies, and I'm always open to new collaborations and learning opportunities.",
        achievement: {
            title: '🌱 Growth Mindset',
            text: 'Committed to continuous improvement and staying at the forefront of emerging technologies.',
        },
    },
];

// New particles.js configuration from contact.html
const particlesConfig = {
    "particles": {
        "number": { "value": 80, "density": { "enable": true, "value_area": 1000 } },
        "color": { "value": ["#ffca28", "#ffa000", "#f57c00", "#ff8c1a"] }, // Default (dark theme)
        "shape": { "type": "circle", "stroke": { "width": 0, "color": "#000000" }},
        "opacity": { "value": 0.6, "random": true, "anim": { "enable": true, "speed": 1.5, "opacity_min": 0.1, "sync": false }},
        "size": { "value": 4, "random": true, "anim": { "enable": true, "speed": 3, "size_min": 0.1, "sync": false }},
        "line_linked": { "enable": true, "distance": 180, "color": "#ffca28", "opacity": 0.5, "width": 1.5 }, // Default (dark theme)
        "move": { "enable": true, "speed": 2.5, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": true, "rotateX": 800, "rotateY": 1200 }}
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" }, "resize": true },
        "modes": { 
            "grab": { "distance": 200, "line_linked": { "opacity": 0.8 } },
            "bubble": { "distance": 300, "size": 8, "duration": 2, "opacity": 0.8, "speed": 3 },
            "repulse": { "distance": 120, "duration": 0.4 },
            "push": { "particles_nb": 6 },
            "remove": { "particles_nb": 2 }
        }
    },
    "retina_detect": true
};


const App: React.FC = () => {
  const [theme, toggleThemeInternal] = useThemeManager();
  const [activePage, setActivePage] = useState<string>('About'); 
  const [loading, setLoading] = useState(true);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const cursorOutlineRef = useRef<HTMLDivElement>(null);

  const updateParticlesTheme = useCallback((currentTheme: 'light' | 'dark') => {
    if (typeof pJSDom !== 'undefined' && pJSDom[0]?.pJS) {
        const pJSInstance = pJSDom[0].pJS;
        if (currentTheme === 'light') {
            pJSInstance.particles.color.value = ["#ffa000", "#f57c00", "#ff8c1a", "#ffb74d"];
            pJSInstance.particles.line_linked.color = "#f57c00";
            pJSInstance.particles.line_linked.opacity = 0.6;
            pJSInstance.particles.opacity.value = 0.4;
        } else { // dark
            pJSInstance.particles.color.value = ["#ffca28", "#ffa000", "#f57c00", "#ff8c1a"];
            pJSInstance.particles.line_linked.color = "#ffca28";
            pJSInstance.particles.line_linked.opacity = 0.5;
            pJSInstance.particles.opacity.value = 0.6;
        }
        pJSInstance.fn.particlesRefresh();
    }
  }, []);
  
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    toggleThemeInternal(); // This will update theme state and localStorage
    // updateParticlesTheme will be called by useEffect watching `theme`
  };

  useEffect(() => { // Preloader
    const preloader = document.getElementById('preloader');
    if (preloader) {
      setTimeout(() => {
        preloader.classList.add('loaded'); // Use class to trigger fade out
        setLoading(false);
      }, 1500); 
    } else {
        setLoading(false);
    }
  }, []);

  useEffect(() => { // Particles.js
    if (!loading && typeof particlesJS !== 'undefined') {
      particlesJS('particles-js', particlesConfig); // Initial load with default (dark) or inferred theme settings
      updateParticlesTheme(theme); // Then adjust to current theme
    }
  }, [loading, theme, updateParticlesTheme]);
  
  useEffect(() => { // Custom Cursor
    const dot = cursorDotRef.current || document.getElementById('cursor-dot') as HTMLDivElement;
    const outline = cursorOutlineRef.current || document.getElementById('cursor-outline') as HTMLDivElement;
    
    if (!dot || !outline) return;

    document.body.classList.add('cursor-ready'); // Make cursors visible

    const moveCursor = (e: MouseEvent) => {
      const posX = e.clientX;
      const posY = e.clientY;
      dot.style.transform = `translate(${posX}px, ${posY}px)`;
      outline.style.transform = `translate(${posX - outline.offsetWidth / 2 + dot.offsetWidth / 2}px, ${posY - outline.offsetHeight / 2 + dot.offsetHeight / 2}px)`;
    };

    const interactiveElements = document.querySelectorAll('a, button, input, select, textarea, [role="button"], .magnetic');
    const addHoverClass = () => outline.classList.add('hover');
    const removeHoverClass = () => outline.classList.remove('hover');

    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', addHoverClass);
        el.addEventListener('mouseleave', removeHoverClass);
    });
    
    window.addEventListener('mousemove', moveCursor);
    
    return () => {
      window.removeEventListener('mousemove', moveCursor);
      interactiveElements.forEach(el => {
          el.removeEventListener('mouseenter', addHoverClass);
          el.removeEventListener('mouseleave', removeHoverClass);
      });
      document.body.classList.remove('cursor-ready');
    };
  }, [loading]); // Depend on loading to ensure cursor setup after preloader
  
  useEffect(() => { // Scroll Progress Bar
    const scrollProgressBar = document.getElementById('scroll-progress-bar');
    if (!scrollProgressBar) return;

    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (scrollHeight > 0) { // Avoid division by zero
        const scrolled = (scrollTop / scrollHeight) * 100;
        scrollProgressBar.style.width = `${scrolled}%`;
      } else {
        scrollProgressBar.style.width = `0%`; // Handle case where content doesn't overflow
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initial call
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);


  const handleNavLinkClick = (pageId: string) => {
    setActivePage(pageId);
    // Optional: Scroll to top of page content, not absolute top (if header is transparent)
    const mainContent = document.querySelector('main');
    if(mainContent) {
        mainContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const navLinks: NavLinkItem[] = initialNavLinksData.map(link => ({
    ...link,
    current: link.pageId === activePage,
  }));
  
  const bodyBgStyle = theme === 'dark' 
    ? { backgroundColor: 'var(--primary-bg)'} 
    : { backgroundColor: 'var(--light-primary-bg)'};
  // Background image (glow-bg) is handled by CSS in index.html based on theme class
  const bodyTextColor = theme === 'dark' ? 'text-[var(--primary-text)]' : 'text-[var(--light-primary-text)]';


  return (
    <div
      style={bodyBgStyle}
      className={`flex flex-col min-h-screen font-['Inter',sans-serif] transition-colors duration-300 ease-linear ${bodyTextColor} `}
    >
      {/* Custom cursor elements are in index.html, styled by CSS. Refs are for direct manipulation if needed but CSS handles most. */}
      {/* <div ref={cursorDotRef} id="cursor-dot"></div> */}
      {/* <div ref={cursorOutlineRef} id="cursor-outline"></div> */}

      <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
      <Header navLinks={navLinks} onNavLinkClick={handleNavLinkClick} />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-10 flex-1 max-w-7xl relative z-[5]"> {/* Adjusted pt for new header style */}
        {activePage === 'About' && (
          <>
            <PageHeaderSection onNavigate={handleNavLinkClick} />
            <StatsSection />
            <TimelineSection timelineEvents={timelineEventsData} />
          </>
        )}
        {activePage === 'Resume' && <ResumePage />}
        {activePage === 'Projects' && <ProjectsPage />}
        {activePage === 'Blog' && <BlogPage />}
        {activePage === 'Contact' && <ContactPage />}
        {activePage === 'Toggles' && <ThemeToggleShowcasePage />}
      </main>
      
      <Footer onNavLinkClick={handleNavLinkClick} />
      <FloatingActionButton onNavigate={handleNavLinkClick} />
      <ChatBot />
    </div>
  );
};

export default App;