export type Theme = 'light' | 'dark';

export interface NavLinkItem {
  name: string;
  pageId: string; 
  href: string; 
  current?: boolean;
}

// Projects Page Specific Types
export interface ProjectCardProps {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
  type: string;
  tags: string[];
  demoLink: string;
  codeLink: string;
}

export interface TimelineEvent {
  id: string;
  category: string;
  icon: string;
  title: string;
  description: string;
  achievement?: {
    title: string;
    text: string;
  };
}

export interface StatItemProps {
  icon: string;
  targetCount: number;
  label: string;
  duration?: number;
}

// Resume Page Specific Types
export interface ResumeContactItem {
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  text: string;
  href: string;
  ariaLabel: string;
}

export interface ResumeSkill {
  name: string;
  level?: number; // 0-100 scale representing proficiency
}

export interface ResumeExperienceEntry {
  role: string;
  company: string;
  dates: string;
  responsibilities: string[];
}

export interface ResumeEducationEntry {
  degree: string;
  institution: string;
  dates: string;
}

export interface ResumeProfessionalDevelopmentEntry {
  item: string;
  source?: string; 
  date?: string; 
}

export interface ResumeReferenceContact {
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  text: string;
  href?: string;
}
export interface ResumeReference {
  name: string;
  title: string;
  contacts: ResumeReferenceContact[];
}

export interface ResumeData {
  fullName: string;
  accentName: string;
  jobTitle: string;
  location: {
    icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
    text: string;
  };
  contactInfo: ResumeContactItem[];
  professionalSummary: string;
  coreCompetencies: {
    skills: ResumeSkill[];
    detailed: Array<{ category: string; items: string }>;
  };
  experience: ResumeExperienceEntry[];
  education: ResumeEducationEntry[];
  professionalDevelopment: ResumeProfessionalDevelopmentEntry[];
  references: ResumeReference[];
}

// Contact Page Specific Types
export interface ContactFormData {
  name: string;
  email: string;
  company?: string;
  budget?: string;
  services?: string[];
  timeline?: string;
  message: string;
}

export interface FAQItemData {
  id: string;
  question: string;
  answer: string;
}

export interface ContactInfoCardData {
    id: string;
    icon: string; // Emoji or SVG path
    title: string;
    description: string;
    buttonText: string;
    buttonLink: string;
    isExternalLink?: boolean;
}

// Blog types
export interface BlogPostProps {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  coverImage: string;
  author: string;
  authorImage?: string;
  category: string;
  tags: string[];
  date: string;
  readTime: string;
}

// Testimonial types
export interface TestimonialProps {
  id: string;
  name: string;
  position: string;
  company: string;
  image: string;
  testimonial: string;
  rating?: number;
}
