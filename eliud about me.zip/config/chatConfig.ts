// ChatBot Configuration

// In a real app, this would come from environment variables
// Replace this with your actual Gemini API key
export const GEMINI_API_KEY = "AIzaSyBLp-EOhxeTiBmqD3SomrrkP55Ry5z-cns";

// Other chat configuration options
export const chatConfig = {
  initialMessage: "Hi there! I'm your AI assistant powered by Gemini. How can I help you today?",
  modelName: "gemini-1.5-flash",
  apiVersion: "v1beta",
  maxTokens: 2048,
}; 